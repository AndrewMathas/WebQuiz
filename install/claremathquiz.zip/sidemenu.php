
    <!-- leftnav -->

      <table width="160" border="0" cellspacing="0" cellpadding="0" class="nav">
        <tr><td height="5" colspan="3"><img src="/img/1px.gif" class="decor" width="1" height="1" alt="" vspace="5"></td></tr>

<tr valign="top"><td nowrap class="navselected">&nbsp;<img
src="/img/nav/right_arrow_red.gif" width="9" height="9"
alt="arrow" />&nbsp;</td><td colspan="2" class="navselected"><a
href="/mathquiz/index.php" class="nav">Maths Quizzes & Resources</a><br><br></td></tr>
<tr valign="top" bgcolor="#FFFFFF">
  <td class="menuDivLine" colspan="3"><img src="/img/navy.gif" width="1" height="2" alt="" class="decor"></td>
</tr>
<tr valign="top"><td class="navselectedsub"><img src="/img/1px.gif" class="decor" width="1" height="1" alt=""></td>
<td width="5" class="navselectedsub"><img src="/img/bullet.gif" width="6" height="9" alt="" hspace="3" vspace="3"></td>
<td width="100%" class="navselectedsub"><a href="#" class="nav">
<a href="/mathquiz/substitution/index.php" class="nav">Substituting into a Formula</a></a></td></tr>
<tr valign="top"><td class="navselectedsub"><img src="/img/1px.gif" class="decor" width="1" height="1" alt=""></td>
<td width="5" class="navselectedsub"><img src="/img/bullet.gif" width="6" height="9" alt="" hspace="3" vspace="3"></td>
<td width="100%" class="navselectedsub"><a href="#" class="nav">
<a href="/mathquiz/manipulation/index.php" class="nav">Algebraic Manipulation</a></a></td></tr>
<tr valign="top"><td class="navselectedsub"><img src="/img/1px.gif" class="decor" width="1" height="1" alt=""></td>
<td width="5" class="navselectedsub"><img src="/img/bullet.gif" width="6" height="9" alt="" hspace="3" vspace="3"></td>
<td width="100%" class="navselectedsub"><a href="#" class="nav">
<a href="/mathquiz/indices/index.php" class="nav">Indices</a></a></td></tr>
<tr valign="top"><td class="navselectedsub"><img src="/img/1px.gif" class="decor" width="1" height="1" alt=""></td>
<td width="5" class="navselectedsub"><img src="/img/bullet.gif" width="6" height="9" alt="" hspace="3" vspace="3"></td>
<td width="100%" class="navselectedsub"><a href="#" class="nav">
<a href="/mathquiz/sigma/index.php" class="nav">Sigma Notation</a></a></td></tr>
<tr valign="top"><td class="navselectedsub"><img src="/img/1px.gif" class="decor" width="1" height="1" alt=""></td>
<td width="5" class="navselectedsub"><img src="/img/bullet.gif" width="6" height="9" alt="" hspace="3" vspace="3"></td>
<td width="100%" class="navselectedsub"><a href="#" class="nav">
<a href="/mathquiz/inequalities/index.php" class="nav">Inequalities</a></a></td></tr>
<tr valign="top"><td class="navselectedsub"><img src="/img/1px.gif" class="decor" width="1" height="1" alt=""></td>
<td width="5" class="navselectedsub"><img src="/img/bullet.gif" width="6" height="9" alt="" hspace="3" vspace="3"></td>
<td width="100%" class="navselectedsub"><a href="#" class="nav">
<a href="/mathquiz/factorial/index.php" class="nav">Factorial Notation</a></a></td></tr>
<tr valign="top"><td class="navselectedsub"><img src="/img/1px.gif" class="decor" width="1" height="1" alt=""></td>
<td width="5" class="navselectedsub"><img src="/img/bullet.gif" width="6" height="9" alt="" hspace="3" vspace="3"></td>
<td width="100%" class="navselectedsub"><a href="#" class="nav">
<a href="/mathquiz/aexp/index.php" class="nav">Exponential Functions</a></a></td></tr>
<tr valign="top"><td class="navselectedsub"><img src="/img/1px.gif" class="decor" width="1" height="1" alt=""></td>
<td width="5" class="navselectedsub"><img src="/img/bullet.gif" width="6" height="9" alt="" hspace="3" vspace="3"></td>
<td width="100%" class="navselectedsub"><a href="#" class="nav">
<a href="/mathquiz/logarithms/index.php" class="nav">Logarithmic Functions</a></a></td></tr>
<tr valign="top"><td class="navselectedsub"><img src="/img/1px.gif" class="decor" width="1" height="1" alt=""></td>
<td width="5" class="navselectedsub"><img src="/img/bullet.gif" width="6" height="9" alt="" hspace="3" vspace="3"></td>
<td width="100%" class="navselectedsub"><a href="#" class="nav">
<a href="/mathquiz/sim-eqns/index.php" class="nav">Simultanous Equations</a></a></td></tr>
<tr valign="top"><td class="navselectedsub"><img src="/img/1px.gif" class="decor" width="1" height="1" alt=""></td>
<td width="5" class="navselectedsub"><img src="/img/bullet.gif" width="6" height="9" alt="" hspace="3" vspace="3"></td>
<td width="100%" class="navselectedsub"><a href="#" class="nav">
<a href="/mathquiz/coordinates/index.php" class="nav">Plotting Coordinates</a></a></td></tr>
<tr valign="top"><td class="navselectedsub"><img src="/img/1px.gif" class="decor" width="1" height="1" alt=""></td>
<td width="5" class="navselectedsub"><img src="/img/bullet.gif" width="6" height="9" alt="" hspace="3" vspace="3"></td>
<td width="100%" class="navselectedsub"><a href="#" class="nav">
<a href="/mathquiz/linear/index.php" class="nav">Straight Line Grahps</a></a></td></tr>
<tr valign="top"><td class="navselectedsub"><img src="/img/1px.gif" class="decor" width="1" height="1" alt=""></td>
<td width="5" class="navselectedsub"><img src="/img/bullet.gif" width="6" height="9" alt="" hspace="3" vspace="3"></td>
<td width="100%" class="navselectedsub"><a href="#" class="nav">
<a href="/mathquiz/quadratics/index.php" class="nav">Quadratic Graphs</a></a></td></tr>
<tr valign="top"><td class="navselectedsub"><img src="/img/1px.gif" class="decor" width="1" height="1" alt=""></td>
<td width="5" class="navselectedsub"><img src="/img/bullet.gif" width="6" height="9" alt="" hspace="3" vspace="3"></td>
<td width="100%" class="navselectedsub"><a href="#" class="nav">
<a href="/mathquiz/gexp/index.php" class="nav">Exponential Graphs</a></a></td></tr>
<tr valign="top"><td class="navselectedsub"><img src="/img/1px.gif" class="decor" width="1" height="1" alt=""></td>
<td width="5" class="navselectedsub"><img src="/img/bullet.gif" width="6" height="9" alt="" hspace="3" vspace="3"></td>
<td width="100%" class="navselectedsub"><a href="#" class="nav">
<a href="/mathquiz/other/index.php" class="nav">Logarithmic and Square Root Graphs</a></a></td></tr>
<tr valign="top"><td class="navselectedsub"><img src="/img/1px.gif" class="decor" width="1" height="1" alt=""></td>
<td width="5" class="navselectedsub"><img src="/img/bullet.gif" width="6" height="9" alt="" hspace="3" vspace="3"></td>
<td width="100%" class="navselectedsub"><a href="#" class="nav">
<a href="/mathquiz/differentiation/index.php" class="nav">Differentiation</a></a></td></tr>
<tr valign="top"><td class="navselectedsub"><img src="/img/1px.gif" class="decor" width="1" height="1" alt=""></td>
<td width="5" class="navselectedsub"><img src="/img/bullet.gif" width="6" height="9" alt="" hspace="3" vspace="3"></td>
<td width="100%" class="navselectedsub"><a href="#" class="nav">
<a href="/mathquiz/integration/index.php" class="nav">Integration</a></a></td></tr>
<tr valign="top" bgcolor="#FFFFFF">
<td class="menuDivLine" colspan="3"><img src="/img/navy.gif" width="1" height="2" alt="" class="decor"></td>
</tr>
