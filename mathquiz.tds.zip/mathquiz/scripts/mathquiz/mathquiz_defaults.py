
MathQuizURL = '/~andrew/mathquiz/'
